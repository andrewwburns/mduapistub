﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Service.Models.Response
{
    public class AuditResponse
    {
        public bool AuditRequestResult { get; set; }
    }
}